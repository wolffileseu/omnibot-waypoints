Read me file for Waypointing-cfg


First: Usage at own risk!! If u dont know, how to deal with cfg's, ask in the forum of www.omni-bot.com

This cfg was written to help you with waypointing.
How to use:

Place the cfg in your etmain
run ET with OmniBot
load a map
open your console and enter:

/exec ob.cfg


To leave the Waypointing mode press "O"

////////////////////////////////////////////////////////////////////////////////////////////////
Credits - Updated config based on Waypointing cfg v0.1 uploaded by Red Dwarf
////////////////////////////////////////////////////////////////////////////////////////////////

Keys-Assignments:

F-Keys:

F5: 					Waypoint_view on/off
F6:					Waypoint_Facing on/off
F7:					Delete a Waypoint
F8:					Move / Place a waypoint

F9:					Axis-Flag added (makes WP Axis-Only)
F10:					Allied-Flag added (makes WP Allied-Only)
F12:					Save your Work

////////////////////////////////////////////////////////////////////////////////////////////////

MouseButtons:

Mouse1:					Add a Waypoint
Mouse2:					Biconnect 2 Waypoints
Mouse3:					Make a single connection

////////////////////////////////////////////////////////////////////////////////////////////////

CursorKeys:

up:					Add a Jump Low Flag
down:					Add a Crouch Flag
left:					Add a Climb Flag
right:					Add a sprint Flag

////////////////////////////////////////////////////////////////////////////////////////////////

Keyboard Jump flags

j:					Add a Jump Flag
k:					Add a Jump Gap Flag


////////////////////////////////////////////////////////////////////////////////////////////////

Waypointradius:

use / and * on the Keypad to cycle through some Waypoint_radii. An echo on the screen will show you, what Radius do you have selected.
After that use - (on the keypad) to change the radius of an existing waypoint to the selected radius. (once you have select your radius,
press - as long as u need it(the selected radius will stay with the key).
If you want to use the selected Radius as default Radius for upcoming Waypoints, press + on the keypad and all of your next WP will have the selected Radius.

Available Radii:
20 35 50 60 75 90 100 125 150


////////////////////////////////////////////////////////////////////////////////////////////////

Keys above the cursor


Page down				Add the Door_flag


////////////////////////////////////////////////////////////////////////////////////////////////


Additional keys:

i					Setfacing
KP_enter				List the Goals and export them to map.txt (Goallist can be found in c:/program Files/wolfenstein/omnibot/map.txt)


////////////////////////////////////////////////////////////////////////////////////////////////

Adding & removing bots

[					Add random Axis bot
]					Add random Allies bot
'					Kickall bots


////////////////////////////////////////////////////////////////////////////////////////////////

o					Return to your "normal" cfg.

if you use a selfwritten cfg enter the name of your cfg in Line 2.		